############################################
#####  Load required functions and packages
############################################
source("necessary_function.R")


library(survival)
library(pracma)
library(ROCR)     # calculte ROC
library(ICsurv)

####################
#       Input      #
####################
seed.start=400

kk=5  #number of knots
nsimu<-100;

n=600

eta0=c(1.5,-5,-3);link="logit";
beta0=c(0.5,-0.5)

E=30;type2=TRUE
####################
#     Settings     #
####################

### data generation settings
lambda=6;lcp=0.25;tend=2.7;tau=4.5

### spline and EM settings
n.int <- 5;order <- 3;E<- 30
max.iter=3000;cov.rate=.001;equal = TRUE

### time grid used for evaluating baseline-related quantities
t.seq<-seq(0,tend,length.out=20)

### prefix of output file names
nmpre<-paste("simu",n,"logit_method",sep="")


############################################
#####  Main simulation loop starts here
############################################
k<-1
while(k<=nsimu){
  
  ### set random seed for the k-th replication
  set.seed(k+seed.start)
  
  ### generate one simulated data set
  Gen.data <- gen.data(n,eta0,beta0,tau,lambda,type2,lcp)
  mdata <- Gen.data$mdata
  
  ########################
  ##### initial values
  ########################
  
  beta.ini<-as.matrix(rep(0,2))
  gamma.ini<-as.matrix(rep(1,n.int+order)) ##2018JCGS
  eta.ini<- as.matrix(rep(0,3))
  
  #########################################
  ##### Logi-based mixture cure model fit
  #########################################
  
  rectm<-system.time(
    Logi.fit<-try(Logi_CCM(survfun=Surv(left,right)~x1+x2,curefun=~z1+z2,data=mdata,
                           beta.ini,gamma.ini,eta.ini,n.int=5,order=3,max.iter,cov.rate=.001),
                  silent=TRUE)
  )
  
  #########################################
  ##### Check convergence and save output
  #########################################
  if(!is.character(Logi.fit)){
    if(Logi.fit$loops<max.iter){
      
      ### bias of estimated uncured probabilities
      Pi_bias=Logi.fit$Uncureprob - mdata$piz
     
      ##write outoput
      write.table(t(Logi.fit$latencyfit),paste(nmpre,"beta.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(Logi.fit$Uncureprob),paste(nmpre,"piz.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(Logi.fit$eta),paste(nmpre,"eta.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(Logi.fit$ispline_gamma),paste(nmpre,"gamma.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(Pi_bias),paste(nmpre,"Pi_bias.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(mdata$ui),paste(nmpre,"Train_ui.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      cat("LOGI_EM converge!\n")
      }
    if(Logi.fit$loops>=max.iter)
    {cat("LOGI_EM not converge!\n")}
  }
  else
  {cat("LOGI_EM generate NA!\n")}
  
  #########################################
  ##### Print simulation progress
  #########################################
  cat(paste("simu=",k,"\n"))
  k<-k+1;
}


############################################
#####  Read output files after simulation
############################################

########################Read OutPut#####################
###########-----LOGI------############
LOGI_Beta <- read.table(paste(nmpre,"beta.txt",sep=""))
LOGI_Eta <- read.table(paste(nmpre,"eta.txt",sep=""))
LOGI_Piz <- read.table(paste(nmpre,"piz.txt",sep=""))
LOGI_Pi_bias <- read.table(paste(nmpre,"Pi_bias.txt",sep=""))

Train_eta <- read.table(paste(nmpre,"Train_ui.txt",sep=""))
############################################
#####  Summarize simulation results
############################################
##LOGI##
LOGI_Beta_bias <- apply(LOGI_Beta,2,mean)-beta0 
#LOGI_Eta_bias <- apply(LOGI_Eta,2,mean)-eta0
LOGI_Piz_bias <- sum(abs(LOGI_Pi_bias))/ncol(LOGI_Pi_bias)/nrow(LOGI_Pi_bias)
LOGI_Beta_sd<-apply(LOGI_Beta,2,sd)


# this is the true label (or true uncured status / true uncured probability, depending on Train_eta)
True_label <- as.vector(as.matrix(Train_eta))

# predicted uncured probabilities from the LOGI-based method
LOGI_pro <- as.vector(as.matrix(LOGI_Piz))

# construct ROC prediction object
pred_LOGI<-ROCR::prediction(LOGI_pro,True_label)

# calculate the AUC value
auc_LOGI<- ROCR::performance(pred_LOGI,measure = "auc")

# extract the AUC from the ROCR object
AUC_train=auc_LOGI@y.values[[1]]


##############################################################################################
######################################Print OUTPUT############################################
##############################################################################################
##LOGI
cat(paste("LOGI_Beta_Bias=",round(LOGI_Beta_bias,3),"\n"))
#cat(paste("LOGI_Eta_Bias=",round(LOGI_Eta_bias,3),"\n"))
cat(paste("LOGI_Beta_Sd=",round(LOGI_Beta_sd,3),"\n"))
cat(paste("LOGI_Piz_Bias=",round(LOGI_Piz_bias,3),"\n"))
cat(paste("AUC_train=",AUC_train,"\n"))

