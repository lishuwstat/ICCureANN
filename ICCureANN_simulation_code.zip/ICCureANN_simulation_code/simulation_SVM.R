############################################
#####  Load required functions and packages
############################################
source("necessary_function.R")

library(survival)
library(pracma)
library(ROCR) #calculte ROC
library(ICsurv)
library(dplyr)
library(e1071)
library(caTools)

####################
#       Input      #
####################
seed.start=400

kk=5  #number of knots
nsimu<-100;

n=300

eta0=c(1.5,-5,-3);
beta0=c(0.5,-0.5)

E=30;type2=TRUE
####################
#     Settings     #
####################

### data generation settings
lambda=6;lcp=0.25;tend=2.7;tau=4.5

### spline and EM settings
n.int <- 5;order <- 3;E<- 30
max.iter=3000;cov.rate=.001;equal = TRUE

### time grid used for evaluating baseline-related quantities
t.seq<-seq(0,tend,length.out=20)

### prefix of output file names
nmpre<-paste("simu",n,"SVM_method",sep="")


############################################
#####  Main simulation loop starts here
############################################
k<-1
while(k<=nsimu){

  ### set random seed for the k-th replication
  set.seed(k+seed.start)
  
  ### generate one simulated data set
  Gen.data <- gen.data(n,eta0,beta0,tau,lambda,type2,lcp)
  mdata <- Gen.data$mdata
  
  ########################
  ##### initial values
  ########################
  rectm<-system.time(
    Logi.fit<-try(Logi_CCM(survfun=Surv(left,right)~x1+x2,curefun=~z1+z2,data=mdata,
                           beta.ini=as.matrix(rep(0,2)),gamma.ini=as.matrix(rep(1,n.int+order)),
                           eta.ini=as.matrix(rep(0,3)),n.int=5,order=3,max.iter,cov.rate=.001),
                  silent=TRUE)
  )
  
  beta.ini<-Logi.fit$latencyfit  # Use the estimates from the method in 2018JCGS as initial values
  gamma.ini<-Logi.fit$ispline_gamma

  #########################################SVM Regression#########################################
  
  rectm<-system.time(
    SVM.fit<-try(SVM_CCM(survfun=Surv(left,right)~x1+x2,curefun=~z1+z2,data=mdata,t.seq,
                           beta.ini,gamma.ini,n.int=5,order=3,max.iter,cov.rate=.001),
                  silent=TRUE)
    )
  
  
  if(!is.character(SVM.fit)){
      Pi_SVM=SVM.fit$Uncureprob - mdata$piz

      ##write outoput

      write.table(t(SVM.fit$latencyfit),paste(nmpre,"beta.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(SVM.fit$Uncureprob),paste(nmpre,"piz.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(SVM.fit$ispline_gamma),paste(nmpre,"gamma.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(Pi_SVM),paste(nmpre,"Pi_bias.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(mdata$ui),paste(nmpre,"Train_ui.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      cat("SVM_EM converge!\n")
  
  }
  else
  {cat("SVM_EM generate NA!\n")}
  
  
  #########################################
  ##### Print simulation progress
  #########################################
  
  cat(paste("simu=",k,"\n"))
  k<-k+1;
}
############################################
#####  Read output files after simulation
############################################

########################Read OutPut#####################

###########-----SVM------############
SVM_Beta <- read.table(paste(nmpre,"beta.txt",sep=""))
SVM_Piz <- read.table(paste(nmpre,"piz.txt",sep=""))
SVM_Pi_bias <- read.table(paste(nmpre,"Pi_bias.txt",sep=""))

Train_eta <- read.table(paste(nmpre,"Train_ui.txt",sep=""))
############################################
#####  Summarize simulation results
############################################
SVM_Beta_bias <- apply(SVM_Beta,2,mean)-beta0 
SVM_Piz_bias <- sum(abs(SVM_Pi_bias))/ncol(SVM_Pi_bias)/nrow(SVM_Pi_bias)
SVM_Beta_sd<-apply(SVM_Beta,2,sd)


# this is the true label (or true uncured status / true uncured probability, depending on Train_eta)
True_label <- as.vector(as.matrix(Train_eta))

# predicted uncured probabilities from the SVM-based method
SVM_pro <- as.vector(as.matrix(SVM_Piz))

# construct ROC prediction object
pred_SVM<-ROCR::prediction(SVM_pro,True_label)

# calculate the AUC value
auc_SVM<- ROCR::performance(pred_SVM,measure = "auc")

# extract the AUC from the ROCR object
AUC_train=auc_SVM@y.values[[1]]
##############################################################################################
######################################Print OUTPUT############################################
##############################################################################################

##############################################################################################
######################################Print OUTPUT############################################
##############################################################################################
##SVM
cat(paste("SVM_Beta_Bias=",SVM_Beta_bias,"\n"))
cat(paste("SVM_Beta_Sd=",SVM_Beta_sd,"\n"))
cat(paste("SVM_Piz_Bias=",SVM_Piz_bias,"\n"))
cat(paste("AUC_train=",AUC_train,"\n"))

