############################################
#####  Load required functions and packages
############################################

source("necessary_function.R")

library(survival)
library(pracma)
library(ROCR)     # calculte ROC
library(ICsurv)
library(neuralnet)


####################
#       Input      #
####################

seed.start=400

kk=5  # number of knots
nsimu<-100;

n=600   # sample size

### true parameters in the cure incidence part
eta0=c(1.5,-5,-3)

### neural network architecture
hidden_layers=c(4,12)

### true parameters in the latency part
beta0=c(0.5,-0.5)

E=30;type2=TRUE

####################
#     Settings     #
####################

### data generation settings
lambda=6;lcp=0.25;tend=2.7;tau=4.5

### spline and EM settings
n.int <- 5;order <- 3;E<- 30
max.iter=3000;cov.rate=.001;equal = TRUE

### time grid used for evaluating baseline-related quantities
t.seq<-seq(0,tend,length.out=20)

### prefix of output file names
nmpre<-paste("simu",n,"NN_method",sep="")


############################################
#####  Main simulation loop starts here
############################################

k<-1
while(k<=nsimu){
  
  ### set random seed for the k-th replication
  set.seed(k+seed.start)
  
  ### generate one simulated data set
  Gen.data <- gen.data(n,eta0,beta0,tau,lambda,type2,lcp)
  mdata <- Gen.data$mdata
  
  ########################
  ##### initial values
  ########################
  
  beta.ini<-as.matrix(rep(0,2))
  gamma.ini<-as.matrix(rep(0.1,n.int+order))
  
  #########################################
  ##### NN-based mixture cure model fit
  #########################################
  
  rectm<-system.time(
    NN.fit<-try(ICCureANN(survfun=Surv(left,right)~x1+x2,curefun=~z1+z2,data=mdata,t.seq,
                          beta.ini,gamma.ini,n.int=5,order=3,max.iter,cov.rate=.001,
                          hidden_layers),
                silent=TRUE)
  )
  
  #########################################
  ##### Check convergence and save output
  #########################################
  
  if(!is.character(NN.fit)){
    if(NN.fit$loops<max.iter){
      
      ### bias of estimated uncured probabilities
      Pi_NN=NN.fit$Uncureprob - mdata$piz
      
      ## write output files for the current replication
      write.table(t(NN.fit$latencyfit),paste(nmpre,"beta.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(NN.fit$Uncureprob),paste(nmpre,"piz.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(NN.fit$loops,paste(nmpre,"loops.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(NN.fit$ispline_gamma),paste(nmpre,"gamma.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(Pi_NN),paste(nmpre,"Pi_bias.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      write.table(t(mdata$ui),paste(nmpre,"Train_ui.txt",sep=""),row.names=FALSE,col.names=FALSE,append=TRUE)
      
      cat("NN_EM converge!\n")
    }
    
    if(NN.fit$loops>=max.iter)
    {cat("NN_EM not converge!\n");}
  }
  else
  {cat("NN_EM generate NA!\n");}
  
  #########################################
  ##### Print simulation progress
  #########################################
  
  cat(paste("simu=",k,"\n"))
  k<-k+1;
}


############################################
#####  Read output files after simulation
############################################

########################Read OutPut#####################

###########-----NN------############

NN_Beta <- read.table(paste(nmpre,"beta.txt",sep=""))
NN_Piz <- read.table(paste(nmpre,"piz.txt",sep=""))
NN_Pi_bias <- read.table(paste(nmpre,"Pi_bias.txt",sep=""))
Train_eta <- read.table(paste(nmpre,"Train_ui.txt",sep=""))
############################################
#####  Summarize simulation results
############################################

## NN ##
NN_Beta_bias <- apply(NN_Beta,2,mean)-beta0 
NN_Piz_bias <- sum(abs(NN_Pi_bias))/ncol(NN_Pi_bias)/nrow(NN_Pi_bias)
NN_Beta_sd<-apply(NN_Beta,2,sd)


# this is the true label (or true uncured status / true uncured probability, depending on Train_eta)
True_label <- as.vector(as.matrix(Train_eta))

# predicted uncured probabilities from the ANN-based method
NN_pro <- as.vector(as.matrix(NN_Piz))

# construct ROC prediction object
pred_NN<-ROCR::prediction(NN_pro,True_label)

# calculate the AUC value
auc_NN<- ROCR::performance(pred_NN,measure = "auc")

# extract the AUC from the ROCR object
AUC_train=auc_NN@y.values[[1]]
##############################################################################################
######################################Print OUTPUT############################################
##############################################################################################

cat(paste("NN_Beta_Bias=",NN_Beta_bias,"\n"))
cat(paste("NN_Beta_Sd=",NN_Beta_sd,"\n"))
cat(paste("NN_Piz_Bias=",NN_Piz_bias,"\n"))
cat(paste("AUC_train=",AUC_train,"\n"))

