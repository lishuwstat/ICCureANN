###############################
#####  Generate data functions
###############################

### baseline cumulative hazard function
Lamd.t<-function(t)  log(1+t)+t^(3/2)

# Lamd.t.t<-function(t)  0.5*t^(5/6)

### auxiliary function used to generate event times numerically
### by solving Lamd.t(t) = lamb
gen.t<-function(tt,lamb){
  dif2<-(Lamd.t(tt)-lamb)^2
  return(dif2)
}

### generate interval-censored mixture cure data
gen.data<-function(n,eta0,beta0,lambda=6,tau=1,type2=TRUE,lcp=0.1){
  ## n: sample size
  ## eta0: regression coefficients in the cure incidence part
  ## beta0: regression coefficients in the latency part
  ## lambda: mean number of observation times when type2 = TRUE
  ## tau: rate parameter in the exponential gap times
  ## type2: whether to generate multiple observation times
  ## link: link function used in the cure part
  ## lcp: lower cut-point for the first monitoring time
  
  z1<-rnorm(n,0,1)
  z2<-rnorm(n,0,1)
  zz<-cbind(z1,z2)
  
  ### uncured probability under different link specifications
  temp<-exp(cbind(1,zz)%*%eta0)/(1+exp(cbind(1,zz)%*%eta0))

  
  ### latent uncured indicator
  ui<-rbinom(n,1,temp)
  
  ### covariates in the latency part
  x1<-z1
  x2<-z2
  exb<-exp(cbind(x1,x2)%*%beta0)
  
  ### generate true failure times from the PH latency model
  U<-runif(n)
  Lamdt<--log(U)/exb
  T<-numeric()
  T<-numeric()
  for(i in 1:n) T[i]<-optimize(gen.t,interval=c(0,1e+8),lamb=Lamdt[i])$minimum
  
  ### generate number of observation times
  if(!type2) nv<-rep(1,n)
  if(type2) nv<-rpois(n,lambda)          # number of observation times
  
  Li<-Ri<-numeric()
  for(i in 1:n){
    di<-rexp(nv[i],tau)           # gap times between observation times
    #di<-runif(nv[i],0,tau)
    vti<-cumsum(c(0,runif(1,0,lcp),di))
    
    ### for uncured subjects, determine interval-censored observation times
    if(ui[i]==1){
      Li[i]<-max(vti[vti<T[i]])
      if(max(vti)>T[i]){Ri[i]<-min(vti[vti>T[i]])} else{Ri[i]<-NA}
    }else{
      ### for cured subjects, only right censoring is observed
      Li[i]<-max(vti)
      Ri[i]<-NA
    }
  }
  
  ### censoring indicators
  d1<-as.numeric(Li==0)         # left censoring indicator
  d3<-as.numeric(is.na(Ri))     # right censoring indicator
  d2<-1-d1-d3                   # interval censoring indicator
  
  Li[d1==1]<-0
  
  ### organize the full generated data
  data<-data.frame(left=Li,right=Ri,x1=x1,x2=x2,z1=z1,z2=z2,ui=ui,piz=temp,Ti=T)
  
  ### split into training and test sets
  # 计算训练集的样本量
  train_size <- floor(2/3 * n)
  
  # 随机抽样，生成训练集索引
  train_indices <- sample(seq_len(n), size = train_size)
  
  # 创建训练集和测试集
  train_data <- data[train_indices, ]
  test_data <- data[-train_indices, ]
  
  rownames(train_data) <- seq_len(nrow(train_data))
  rownames(test_data) <- seq_len(nrow(test_data))
  
  # 打印数据集大小
  # cat("训练集大小:", nrow(train_data), "\n")
  # cat("测试集大小:", nrow(test_data), "\n")
  

  return(list(mdata=train_data,tdata=test_data))
}


########################
#####  EM sub-functions
########################

### objective function in the M-step for updating beta
bb.gamma0 <-
  function(bb,sdata,Xp,Eyil,Ewil,Eui,bl.Li,bl.Ri){
    N<-nrow(sdata)
    L<-nrow(bl.Li)
    
    ### row-wise and column-wise matrix expansion helpers
    r.mat<-function(x) matrix(x,ncol=N,nrow=L,byrow=TRUE)
    c.mat<-function(x) matrix(x,ncol=N,nrow=L)
    
    exb<-exp(Xp%*%bb)
    gg<-gg.beta0(bb,sdata,Xp,Eyil,Ewil,Eui,bl.Li,bl.Ri)
    
    ### first part of Q-function involving log gamma and beta
    prt1<-(c.mat(log(gg))+r.mat(log(exb)))*(Eyil+Ewil)
    
    ### second part of Q-function involving cumulative baseline hazard
    prt2<-c.mat(gg)*(r.mat(exb*(1-sdata$d3))*bl.Ri+r.mat(exb*sdata$d3*Eui)*bl.Li)
    
    Q<-sum(prt1-prt2)
    return(-Q)
  }

### closed-form update of gamma given beta
gg.beta0 <-
  function(bb,sdata,Xp,Eyil,Ewil,Eui,bl.Li,bl.Ri){
    N<-nrow(sdata)
    L<-nrow(bl.Li)
    
    r.mat<-function(x) matrix(x,ncol=N,nrow=L,byrow=TRUE)
    c.mat<-function(x) matrix(x,ncol=N,nrow=L)
    
    exb<-exp(Xp%*%bb)
    
    ### numerator and denominator for gamma update
    numer<-apply(Eyil+Ewil,1,sum)
    denom<-apply(r.mat((1-sdata$d3)*exb)*bl.Ri+r.mat(sdata$d3*exb*Eui)*bl.Li,1,sum)
    
    gg<-numer/denom
    return(gg)
  }

### observed log-likelihood under current parameter values
loglik <-
  function(x0,pzi,sdata,Xp,Zp,bl.Li,bl.Ri){
    P<-ncol(Xp)
    b0<-x0[1:P]
    g0<-x0[(P+1):(8+P)]
    
    exb<-exp(Xp%*%b0)
    Lamd.Li<-t(bl.Li)%*%matrix(g0,ncol=1)
    Lamd.Ri<-t(bl.Ri)%*%matrix(g0,ncol=1)
    
    ### contribution from the cure part
    pc0<-(1-sdata$d3)*log(pzi)
    
    ### contribution from left-, interval-, and right-censored observations
    pc1<-sdata$d1*(1-exp(-Lamd.Ri*exb))
    pc2<-sdata$d2*(exp(-Lamd.Li*exb)-exp(-Lamd.Ri*exb))
    pc3<-sdata$d3*(1-pzi+pzi*exp(-Lamd.Li*exb))
    
    ll<-sum(pc0+log(pc1+pc2+pc3))
    return(-ll)
  }

###logi-based method
loglik2 <-
  function(x0,sdata,Xp,Zp,bl.Li,bl.Ri){
    M<-ncol(Zp)
    P<-ncol(Xp)
    e0<-x0[1:M]
    b0<-x0[(M+1):(M+P)]
    g0<-x0[-c(1:(M+P))]
    pzi<-exp(Zp%*%e0)/(1+exp(Zp%*%e0))
    exb<-exp(Xp%*%b0)
    Lamd.Li<-t(bl.Li)%*%matrix(g0,ncol=1)
    Lamd.Ri<-t(bl.Ri)%*%matrix(g0,ncol=1)
    pc0<-(1-sdata$d3)*log(pzi)
    
    pc1<-sdata$d1*(1-exp(-Lamd.Ri*exb))
    pc2<-sdata$d2*(exp(-Lamd.Li*exb)-exp(-Lamd.Ri*exb))
    pc3<-sdata$d3*(1-pzi+pzi*exp(-Lamd.Li*exb))
    
    ll<-sum(pc0+log(pc1+pc2+pc3))
    return(-ll)
  }
#####################################
#####  Neural network update step
#####################################

NN_Cure=function(Eui,inputdata,N,M,best_hidden_layers,threshold){
  ###################################### NN step#####################################
  
  ### generate multiple binary imputations of the latent uncured indicator
  multipleuncureprob=matrix(1:5*N, nrow=N,ncol=5)  #形成矩阵
  for (j in 1:N){multipleuncureprob[j,] <- rbinom(5,size = 1,prob=Eui[j])}  #对矩阵赋值 model the response as binary
  
  uncureprob1 <- uncureprob2 <- uncureprob3 <- uncureprob4 <- uncureprob5 <-  c(1 ,1) 
  
  uncureprob1=as.factor(multipleuncureprob[,1])
  uncureprob2=as.factor(multipleuncureprob[,2])
  uncureprob3=as.factor(multipleuncureprob[,3])
  uncureprob4=as.factor(multipleuncureprob[,4])
  uncureprob5=as.factor(multipleuncureprob[,5])
  
  update_cureb <- c(1,1) 
  
  ##################################    NN  ####    5 ——multiple imputation-based technique #############################    
  
  ### use five imputed binary responses to train five neural networks
  dataa1=data.frame(uncureprob1,inputdata)
  k <- ncol(inputdata)
  z_names <- paste0("z", 1:k)
  z_terms <- paste(z_names, collapse = " + ")
  fml1b <- stats::as.formula(paste0("(uncureprob1 == 1) ~ ", z_terms))
  
  # #####################NN 1
  # 定义神经网络结构并训练模型
  mod1 <- neuralnet(
    fml1b, 
    data = dataa1, 
    hidden = best_hidden_layers, # 设置隐藏层神经元数量
    threshold = threshold, 
    linear.output = FALSE, 
    act.fct = 'logistic'
  )
  update_cureb1=as.vector(neuralnet::compute(mod1,inputdata)$net.result)
  
  ############NN 2
  dataa2=data.frame(uncureprob2,inputdata)
  fml2b <- stats::as.formula(paste0("(uncureprob2 == 1) ~ ", z_terms))
  mod2 <- neuralnet(
    fml2b,  
    data = dataa2, 
    hidden = best_hidden_layers, 
    threshold = threshold, 
    linear.output = FALSE, 
    act.fct = 'logistic' 
  )
  update_cureb2=as.vector(neuralnet::compute(mod2,inputdata)$net.result)
  
  ############NN 3
  dataa3=data.frame(uncureprob3,inputdata)
  fml3b <- stats::as.formula(paste0("(uncureprob3 == 1) ~ ", z_terms))
  mod3 <- neuralnet(
    fml3b,  
    data = dataa3, 
    hidden = best_hidden_layers, 
    threshold = threshold, 
    linear.output = FALSE, 
    act.fct = 'logistic'         
  )
  update_cureb3=as.vector(neuralnet::compute(mod3,inputdata)$net.result)
  
  ############NN 4
  dataa4=data.frame(uncureprob4,inputdata)
  fml4b <- stats::as.formula(paste0("(uncureprob4 == 1) ~ ", z_terms))
  mod4 <- neuralnet(
    fml4b,  
    data = dataa4, 
    hidden = best_hidden_layers, 
    threshold = threshold, 
    linear.output = FALSE, 
    act.fct = 'logistic'       
  )
  update_cureb4=as.vector(neuralnet::compute(mod4,inputdata)$net.result)
  
  ############NN 5
  dataa5=data.frame(uncureprob5,inputdata)
  fml5b <- stats::as.formula(paste0("(uncureprob5 == 1) ~ ", z_terms))
  mod5 <- neuralnet(
    fml5b,  
    data = dataa5, 
    hidden = best_hidden_layers, 
    threshold = threshold, 
    linear.output = FALSE, 
    act.fct = 'logistic'           
  )
  update_cureb5=as.vector(neuralnet::compute(mod5,inputdata)$net.result)
  
  ### average the predicted uncured probabilities over five imputations
  #multi-imputation
  for (z in 1:N){update_cureb[z] <- (update_cureb1[z] + update_cureb2[z] + update_cureb3[z] + 
                                       update_cureb4[z] + update_cureb5[z]) / 5} 
  
  return(list(uncureprob=update_cureb,mod1=mod1,mod2=mod2,mod3=mod3,mod4=mod4,mod5=mod5))
}


##############################################
#####  Main function: ICCureANN estimation
##############################################

ICCureANN <-
  function(survfun=formula(data),curefun=formula(data),data=parent.frame(),t.seq,
           beta.ini,gamma.ini,n.int=5,order=3,max.iter=1000,
           cov.rate=.001,hidden_layers){
    
    ### prepare input data and model frame
    sdata<-data
    call <- match.call()
    mf <- match.call(expand.dots = FALSE)
    temp <- c("", "formula", "data", "na.action")
    mf <- mf[match(temp, names(mf), nomatch = 0)]
    mf[[1]] <- as.name("model.frame")
    
    ### construct survival formula in interval-censored format
    avars<-all.vars(survfun)
    survfun1<-as.formula(paste("Surv(",avars[1],",",avars[2],",type='interval2')~",paste(avars[-c(1,2)],collapse="+"),sep=""))
    
    temp.x<-terms(survfun1, data = sdata)
    temp.z<-terms(curefun, data = sdata)
    mf$formula<-temp.x
    mf <- eval(mf, envir=parent.frame())
    Y <- model.extract(mf, "response")
    
    ### remove intercept from model matrices
    attr(temp.x, "intercept") <- 0
    attr(temp.z, "intercept") <- 0
    
    ### design matrices for latency and cure components
    Xp <- model.matrix(temp.x,sdata)
    colnames(Xp)<-paste("x",1:ncol(Xp),sep="")
    Zp <- model.matrix(temp.z,sdata)
    colnames(Zp)<-paste("z",c(1:ncol(Zp)),sep="")
    Zp=data.frame(Zp)
    
    ### construct censoring indicators and interval endpoints
    sdata$d1<-as.numeric(Y[,3]==2)
    sdata$d2<-as.numeric(Y[,3]==3)
    sdata$d3<-as.numeric(Y[,3]==0) 
    sdata$Li<-Y[,1]
    sdata$Li[sdata$d1==1]<-0
    sdata$Ri<-Y[,2]
    sdata$Ri[sdata$d1==1]<-Y[sdata$d1==1,1]
    sdata$Ri[sdata$d3==1]<-NA
    
    # Estimates
    P<-ncol(Xp)   # dimension of latency covariates
    M<-ncol(Zp)   # dimension of cure covariates
    L<-n.int+order   # number of I-spline basis functions
    N<-nrow(sdata)   # sample size
    
    ### initial values
    b0<-beta.ini
    g0<-gamma.ini
    
    ### row-wise and column-wise matrix expansion helpers
    r.mat<-function(x) matrix(x,ncol=N,nrow=L,byrow=TRUE)
    c.mat<-function(x) matrix(x,ncol=N,nrow=L)
    
    ### determine spline knots from observed interval endpoints
    ti <- c(sdata$Li[sdata$d1 == 0], sdata$Ri[sdata$d3 == 0])
    ti.max <- max(ti) + 1e-05
    ti.min <- min(ti) - 1e-05
    #knots <- seq(ti.min, ti.max, length.out = (n.int + 2))
    knots <-quantile(ti,seq(0,1,length.out = (n.int + 2)))
    
    ### construct I-spline basis matrices at left and right endpoints
    bl.Li<-bl.Ri<-matrix(0,nrow=L,ncol=N)
    bt <-Ispline(t.seq,order=order,knots=knots)
    bl.Li[,sdata$d1==0]<-Ispline(sdata$Li[sdata$d1==0],order=order,knots=knots)
    bl.Ri[,sdata$d3==0]<-Ispline(sdata$Ri[sdata$d3==0],order=order,knots=knots)
    
    ### storage for iterative estimation
    dif<-numeric()
    est.par<-matrix(ncol=P+L,nrow=max.iter)
    Eui<-last_pzi<-1-sdata$d3
    
    ll<-numeric()
    threshold <- 0.1
    dd<-1
    ii<-0
    
    #####################################
    #####  EM algorithm starts
    #####################################
    
    while(dd>cov.rate & ii<max.iter){
      ii<-ii+1
      
      ############################
      ##### E-step: cure part
      ############################
      
      NN_train=NN_Cure(Eui,Zp,N,M,hidden_layers,threshold)
      pzi<-NN_train$uncureprob
      
      ############################
      ##### E-step: latency part
      ############################
      
      exb<-exp(Xp%*%b0)
      Lamd.Li<-t(bl.Li)%*%matrix(g0,ncol=1)
      Lamd.Ri<-t(bl.Ri)%*%matrix(g0,ncol=1)
      
      ### quantities used in the conditional expectations
      lambdai<-exb*(sdata$d1*Lamd.Ri+sdata$d2*Lamd.Li)
      omegai<-exb*(sdata$d2*(Lamd.Ri-Lamd.Li)+sdata$d3*Lamd.Li)
      lambdail<-c.mat(g0)*(r.mat(sdata$d1*exb)*bl.Ri+r.mat(sdata$d2*exb)*bl.Li)
      omegail<-c.mat(g0)*(r.mat(sdata$d2*exb)*(bl.Ri-bl.Li)+r.mat(sdata$d3*exb)*bl.Li)
      
      ci<-1-exp(-sdata$d1*lambdai)
      di<-1-exp(-sdata$d2*omegai)
      
      ### conditional expectations of latent Poisson variables
      Eyil<-r.mat(sdata$d1/(sdata$d1*ci+1-sdata$d1))*lambdail
      Ewil<-r.mat(sdata$d2/(sdata$d2*di+1-sdata$d2))*omegail
      Eyi<-apply(Eyil,2,sum)      
      Ewi<-apply(Ewil,2,sum)
      
      ### conditional expectation of latent uncured indicator
      Eui<-1-sdata$d3+sdata$d3*pzi*exp(-Lamd.Li*exb)/(1-pzi+pzi*exp(-Lamd.Li*exb))
      
      ############################
      ##### M-step
      ############################
      
      fit2<-nlm(bb.gamma0,p=b0,sdata=sdata,Xp=Xp,Eyil=Eyil,Ewil=Ewil,Eui=Eui,bl.Li=bl.Li,bl.Ri=bl.Ri)
      
      if(!is.character(pzi) & !is.character(fit2)){
        b0<-fit2$estimate
        g0<-gg.beta0(bb=b0,sdata=sdata,Xp=Xp,Eyil=Eyil,Ewil=Ewil,Eui=Eui,bl.Li=bl.Li,bl.Ri=bl.Ri)
        est.par[ii,]<-c(b0,g0)
        ll<-c(ll,loglik(x0=est.par[ii,],pzi,sdata=sdata,Xp=Xp,Zp=Zp,bl.Li=bl.Li,bl.Ri=bl.Ri))
      }
      
      ### convergence criterion
      if(ii>2) dd<-sum(c(mean(pzi)-mean(last_pzi),b0-est.par[ii-1,1:2],g0-est.par[ii-1,3:10])^2)
      last_pzi=pzi
      
      ### print current latency estimates and convergence measure
      print(round(c(b0,dd),3))
    }
    
    #####################################
    #####  After convergence
    #####################################
    
    loglik <- ll[ii]
    NN.em <- list(latencyfit=b0,ispline_gamma=g0,Uncureprob=pzi,Loglikelihood=loglik,tau=dd,
                  mdata=sdata,loops=ii,order=order,knots=knots,mod1=NN_train$mod1,mod2=NN_train$mod2,
                  mod3=NN_train$mod3,mod4=NN_train$mod4,mod5=NN_train$mod5)
    return(NN.em)
  }

##############################################
#####  function: LOGI estimation
##############################################
Logi_CCM <-
  function(survfun=formula(data),curefun=formula(data),data=parent.frame(),
           beta.ini,gamma.ini,eta.ini,n.int=5,order=3,max.iter=1000,
           cov.rate=.001){
    # Copy input data and parse model components
    sdata<-data
    call <- match.call()
    mf <- match.call(expand.dots = FALSE)
    temp <- c("", "formula", "data", "na.action")
    mf <- mf[match(temp, names(mf), nomatch = 0)]
    mf[[1]] <- as.name("model.frame")
    avars<-all.vars(survfun)
    survfun1<-as.formula(paste("Surv(",avars[1],",",avars[2],",type='interval2')~",paste(avars[-c(1,2)],collapse="+"),sep=""))
    
    # Construct design matrices for latency and incidence parts
    temp.x<-terms(survfun1, data = sdata)
    temp.z<-terms(curefun, data = sdata)
    mf$formula<-temp.x
    mf <- eval(mf, envir=parent.frame())
    Y <- model.extract(mf, "response")
    attr(temp.x, "intercept") <- 0
    attr(temp.z, "intercept") <- 1
    Xp <- model.matrix(temp.x,sdata)
    colnames(Xp)<-paste("x",1:ncol(Xp),sep="")
    Zp <- model.matrix(temp.z,sdata)
    colnames(Zp)<-paste("z",c(1:ncol(Zp))-1,sep="")
    
    # Define censoring indicators and interval endpoints
    sdata$d1<-as.numeric(Y[,3]==2)
    sdata$d2<-as.numeric(Y[,3]==3)
    sdata$d3<-as.numeric(Y[,3]==0) 
    sdata$Li<-Y[,1]
    sdata$Li[sdata$d1==1]<-0
    sdata$Ri<-Y[,2]
    sdata$Ri[sdata$d1==1]<-Y[sdata$d1==1,1]
    sdata$Ri[sdata$d3==1]<-NA
    
    # Dimensions and initial values
    P<-ncol(Xp)
    M<-ncol(Zp)
    L<-n.int+order
    N<-nrow(sdata)
    b0<-beta.ini
    e0<-eta.ini
    g0<-gamma.ini
    
    # Helper functions for matrix expansion
    r.mat<-function(x) matrix(x,ncol=N,nrow=L,byrow=TRUE)
    c.mat<-function(x) matrix(x,ncol=N,nrow=L)
    
    # Construct spline basis
    ti <- c(sdata$Li[sdata$d1 == 0], sdata$Ri[sdata$d3 == 0])
    ti.max <- max(ti) + 1e-05
    ti.min <- min(ti) - 1e-05
    #knots <- seq(ti.min, ti.max, length.out = (n.int + 2))
    knots <-quantile(ti,seq(0,1,length.out = (n.int + 2)))
    
    bl.Li<-bl.Ri<-matrix(0,nrow=L,ncol=N)
    bl.Li[,sdata$d1==0]<-Ispline(sdata$Li[sdata$d1==0],order=order,knots=knots)
    bl.Ri[,sdata$d3==0]<-Ispline(sdata$Ri[sdata$d3==0],order=order,knots=knots)
    
    # EM algorithm initialization
    dif<-numeric()
    est.par<- matrix(ncol=M+P+L,nrow=max.iter)
    ll<-numeric()
    dd<-1
    ii<-0
    while(dd>cov.rate & ii<max.iter){
      ii<-ii+1
      
      # E-step: compute posterior quantities
      pzi<-exp(Zp%*%e0)/(1+exp(Zp%*%e0))
      last_pzi <- pzi
      exb<-exp(Xp%*%b0)
      Lamd.Li<-t(bl.Li)%*%matrix(g0,ncol=1)
      Lamd.Ri<-t(bl.Ri)%*%matrix(g0,ncol=1)
      
      lambdai<-exb*(sdata$d1*Lamd.Ri+sdata$d2*Lamd.Li)
      omegai<-exb*(sdata$d2*(Lamd.Ri-Lamd.Li)+sdata$d3*Lamd.Li)
      lambdail<-c.mat(g0)*(r.mat(sdata$d1*exb)*bl.Ri+r.mat(sdata$d2*exb)*bl.Li)
      omegail<-c.mat(g0)*(r.mat(sdata$d2*exb)*(bl.Ri-bl.Li)+r.mat(sdata$d3*exb)*bl.Li)
      
      ci<-1-exp(-sdata$d1*lambdai)
      di<-1-exp(-sdata$d2*omegai)
      Eyil<-r.mat(sdata$d1/(sdata$d1*ci+1-sdata$d1))*lambdail
      Ewil<-r.mat(sdata$d2/(sdata$d2*di+1-sdata$d2))*omegail
      Eyi<-apply(Eyil,2,sum)      
      Ewi<-apply(Ewil,2,sum)
      
      Eui<-1-sdata$d3+sdata$d3*pzi*exp(-Lamd.Li*exb)/(1-pzi+pzi*exp(-Lamd.Li*exb))
      
      # M-step: update incidence and latency parameters
      fit1.data<-data.frame(ui=Eui,Zp)
      tempf<-paste("z",1:(M-1),sep="",collapse="+")
      formu<-paste("ui~",tempf)
      
      fit1<-glm(formu,fit1.data,family=quasibinomial("logit"))
      
      fit2<-nlm(bb.gamma0,p=b0,sdata=sdata,Xp=Xp,Eyil=Eyil,Ewil=Ewil,Eui=Eui,bl.Li=bl.Li,bl.Ri=bl.Ri)
      
      if(!is.character(fit1) & !is.character(fit2)){
        e0<-fit1$coef
        b0<-fit2$estimate
        g0<-gg.beta0(bb=b0,sdata=sdata,Xp=Xp,Eyil=Eyil,Ewil=Ewil,Eui=Eui,bl.Li=bl.Li,bl.Ri=bl.Ri)
        pzi<-exp(Zp%*%e0)/(1+exp(Zp%*%e0))
        est.par<-as.numeric(c(e0,b0,g0))
        ll<-c(ll,loglik2(x0=est.par,sdata=sdata,Xp=Xp,Zp=Zp,bl.Li=bl.Li,bl.Ri=bl.Ri))
      }
      
      # Convergence check
      if(ii>2) dd<-sum(c(mean(pzi)-mean(last_pzi),b0-last_b0,g0-last_g0)^2)
      last_g0=g0
      last_b0=b0
      #if(ii>2) dd<-abs(ll[ii]-ll[ii-1])
      print(c(dd))
    }
    
    # Final estimates after convergence
    pzi<-exp(Zp%*%e0)/(1+exp(Zp%*%e0))
    loglik <- ll[ii]
    Logi.em <- list(latencyfit=b0,ispline_gamma=g0,eta=e0,Uncureprob=pzi,Loglikelihood=loglik,tau=dd,mdata=sdata,loops=ii,order=order,knots=knots)
    return(Logi.em)
  }

SVM_CCM <-
  function(survfun=formula(data),curefun=formula(data),data=parent.frame(),t.seq,
           beta.ini,gamma.ini,n.int=5,order=3,max.iter=1000,
           cov.rate=.001){
    # Copy input data and parse model components
    sdata<-data
    call <- match.call()
    mf <- match.call(expand.dots = FALSE)
    temp <- c("", "formula", "data", "na.action")
    mf <- mf[match(temp, names(mf), nomatch = 0)]
    mf[[1]] <- as.name("model.frame")
    avars<-all.vars(survfun)
    survfun1<-as.formula(paste("Surv(",avars[1],",",avars[2],",type='interval2')~",paste(avars[-c(1,2)],collapse="+"),sep=""))
    
    # Construct design matrices for latency and incidence parts
    temp.x<-terms(survfun1, data = sdata)
    temp.z<-terms(curefun, data = sdata)
    mf$formula<-temp.x
    mf <- eval(mf, envir=parent.frame())
    Y <- model.extract(mf, "response")
    attr(temp.x, "intercept") <- 0
    attr(temp.z, "intercept") <- 0
    Xp <- model.matrix(temp.x,sdata)
    colnames(Xp)<-paste("x",1:ncol(Xp),sep="")
    Zp <- model.matrix(temp.z,sdata)
    colnames(Zp)<-paste("z",c(1:ncol(Zp)),sep="")
    Zp=data.frame(Zp)
    
    # Define censoring indicators and interval endpoints
    sdata$d1<-as.numeric(Y[,3]==2)
    sdata$d2<-as.numeric(Y[,3]==3)
    sdata$d3<-as.numeric(Y[,3]==0) 
    sdata$Li<-Y[,1]
    sdata$Li[sdata$d1==1]<-0
    sdata$Ri<-Y[,2]
    sdata$Ri[sdata$d1==1]<-Y[sdata$d1==1,1]
    sdata$Ri[sdata$d3==1]<-NA
    
    # Dimensions and initial values
    P<-ncol(Xp)
    M<-ncol(Zp)
    L<-n.int+order
    N<-nrow(sdata)
    b0<-beta.ini
    g0<-gamma.ini
    
    # Helper functions for matrix expansion
    r.mat<-function(x) matrix(x,ncol=N,nrow=L,byrow=TRUE)
    c.mat<-function(x) matrix(x,ncol=N,nrow=L)
    
    # Construct spline basis
    ti <- c(sdata$Li[sdata$d1 == 0], sdata$Ri[sdata$d3 == 0])
    ti.max <- max(ti) + 1e-05
    ti.min <- min(ti) - 1e-05
    #knots <- seq(ti.min, ti.max, length.out = (n.int + 2))
    knots <-quantile(ti,seq(0,1,length.out = (n.int + 2)))
    
    bl.Li<-bl.Ri<-matrix(0,nrow=L,ncol=N)
    bt <-Ispline(t.seq,order=order,knots=knots)
    bl.Li[,sdata$d1==0]<-Ispline(sdata$Li[sdata$d1==0],order=order,knots=knots)
    bl.Ri[,sdata$d3==0]<-Ispline(sdata$Ri[sdata$d3==0],order=order,knots=knots)
    
    # EM algorithm initialization
    dif<-numeric()
    est.par<-matrix(ncol=P+L,nrow=max.iter)
    Eui<-last_pzi<-1-sdata$d3
    
    
    ll<-numeric()
    dd<-1
    ii<-0
    while(dd>cov.rate & ii<max.iter){
      ii<-ii+1
      
      # Multiple imputation for latent uncured status
      multipleuncureprob=matrix(1:5*N, nrow=N,ncol=5)
      for (j in 1:N){multipleuncureprob[j,] <- rbinom(5,size = 1,prob=Eui[j])}
      
      uncureprob1 <- uncureprob2 <- uncureprob3 <- uncureprob4 <- uncureprob5 <-  c(1 ,1) 
      
      uncureprob1=as.factor(multipleuncureprob[,1])
      uncureprob2=as.factor(multipleuncureprob[,2])
      uncureprob3=as.factor(multipleuncureprob[,3])
      uncureprob4=as.factor(multipleuncureprob[,4])
      uncureprob5=as.factor(multipleuncureprob[,5])
      
      update_cureb <- c(1,1) 
      data1=data.frame(y=uncureprob1,Zp)
      
      # Tune SVM hyperparameters using the first imputed dataset
      obj <- tune(
        svm,
        y ~ ., data=data1,
        kernel="radial",
        ranges=list(
          gamma = 2^seq(-4,1,1),   # 扩大搜索范围
          cost  = 2^seq(0,6,2)
        ),
        tunecontrol=tune.control(sampling="fix")
      )
      
      best_g = obj$best.parameters$gamma
      best_c = obj$best.parameters$cost
      
      # Train SVM and extract fitted uncured probabilities
      train <- function(y, Zp, best_g, best_c){
        
        
        mod <- svm(Zp, y,
                   method="C-classification",
                   kernel="radial",
                   gamma=best_g, cost=best_c,
                   probability=TRUE)
        
        pred <- predict(mod, Zp, probability=TRUE)
        
        prob <- attr(pred, "probabilities")[, "1"]
        
        return(list(prob=prob,mod=mod))
      }
      
      # Fit SVM on each imputed dataset
      SVM1 <- train(uncureprob1, Zp, best_g, best_c)
      update_cureb1 <- SVM1$prob
      mod1 <- SVM1$mod
      SVM2 <- train(uncureprob2, Zp, best_g, best_c)
      update_cureb2 <- SVM2$prob
      mod2 <- SVM2$mod
      SVM3 <- train(uncureprob3, Zp, best_g, best_c)
      update_cureb3 <- SVM3$prob
      mod3 <- SVM3$mod
      SVM4 <- train(uncureprob4, Zp, best_g, best_c)
      update_cureb4 <- SVM4$prob
      mod4 <- SVM4$mod
      SVM5 <- train(uncureprob5, Zp, best_g, best_c)
      update_cureb5 <- SVM5$prob
      mod5 <- SVM5$mod
      
      # Average fitted probabilities across imputations
      for (z in 1:N){update_cureb[z]<-(update_cureb1[z]+update_cureb2[z]+update_cureb3[z]+update_cureb4[z]+update_cureb5[z])/5}
      pzi=update_cureb
      
      # E-step for latency component
      exb<-exp(Xp%*%b0)
      Lamd.Li<-t(bl.Li)%*%matrix(g0,ncol=1)
      Lamd.Ri<-t(bl.Ri)%*%matrix(g0,ncol=1)
      
      lambdai<-exb*(sdata$d1*Lamd.Ri+sdata$d2*Lamd.Li)
      omegai<-exb*(sdata$d2*(Lamd.Ri-Lamd.Li)+sdata$d3*Lamd.Li)
      lambdail<-c.mat(g0)*(r.mat(sdata$d1*exb)*bl.Ri+r.mat(sdata$d2*exb)*bl.Li)
      omegail<-c.mat(g0)*(r.mat(sdata$d2*exb)*(bl.Ri-bl.Li)+r.mat(sdata$d3*exb)*bl.Li)
      
      ci<-1-exp(-sdata$d1*lambdai)
      di<-1-exp(-sdata$d2*omegai)
      Eyil<-r.mat(sdata$d1/(sdata$d1*ci+1-sdata$d1))*lambdail
      Ewil<-r.mat(sdata$d2/(sdata$d2*di+1-sdata$d2))*omegail
      Eyi<-apply(Eyil,2,sum)      
      Ewi<-apply(Ewil,2,sum)
      
      Eui<-1-sdata$d3+sdata$d3*pzi*exp(-Lamd.Li*exb)/(1-pzi+pzi*exp(-Lamd.Li*exb))
      
      # M-step: update latency parameters
      fit2<-nlm(bb.gamma0,p=b0,sdata=sdata,Xp=Xp,Eyil=Eyil,Ewil=Ewil,Eui=Eui,bl.Li=bl.Li,bl.Ri=bl.Ri)
      
      if(!is.character(pzi) & !is.character(fit2)){
        b0<-fit2$estimate
        g0<-gg.beta0(bb=b0,sdata=sdata,Xp=Xp,Eyil=Eyil,Ewil=Ewil,Eui=Eui,bl.Li=bl.Li,bl.Ri=bl.Ri)
        est.par[ii,]<-c(b0,g0)
        ll<-c(ll,loglik(x0=est.par[ii,],pzi,sdata=sdata,Xp=Xp,Zp=Zp,bl.Li=bl.Li,bl.Ri=bl.Ri))
      }
      
      # Convergence check
      if(ii>2) dd<-sum(c(mean(pzi)-mean(last_pzi),b0-est.par[ii-1,1:2],g0-est.par[ii-1,3:10])^2)
      last_pzi=pzi
      print(round(c(b0,dd),3))
    }
    
    # Final estimates after convergence
    loglik <- ll[ii]
    SVM.em <- list(latencyfit=b0,ispline_gamma=g0,Uncureprob=pzi,Loglikelihood=loglik,tau=dd,
                  mdata=sdata,loops=ii,order=order,knots=knots,
                  mod1=mod1,mod2=mod2,mod3=mod3,mod4=mod4,mod5=mod5)
    return(SVM.em)
  }