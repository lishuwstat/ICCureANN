# ICCureANN

**ICCureANN** is an R package for fitting **mixture cure rate models with artificial neural networks**
for **interval-censored data**.

The package implements an EM algorithm that combines:
- a neural network model for the uncure part, and
- a proportional hazards (PH) model with monotone-spline approximation.

This framework is particularly useful when the relationship between covariates and cure probability
is nonlinear or complex.

---

## 📦 Installation

### Install from source (tar.gz)

If you have the source package file `ICCureANN_0.1.0.tar.gz`, install it in R via:

```r
install.packages("ICCureANN_0.1.0.tar.gz", repos = NULL, type = "source")
library(ICCureANN)
?ICCureANN              
?predict_NN


