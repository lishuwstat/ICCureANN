# NNCox

**NNCox** is an R package for fitting **mixture cure rate models with artificial neural networks**
for **interval-censored survival data**.

The package implements an EM algorithm that combines:
- a neural network model for the cure (incidence) component, and
- a proportional hazards model with I-spline approximation for the latency component.

This framework is particularly useful when the relationship between covariates and cure probability
is nonlinear or complex.

---

## 📦 Installation

### Install from source (tar.gz)

If you have the source package file `NNCox_0.1.0.tar.gz`, install it in R via:

```r
install.packages("NNCox_0.1.0.tar.gz", repos = NULL, type = "source")
library(NNCox)
?NN_CCM              
?predict_pzi


