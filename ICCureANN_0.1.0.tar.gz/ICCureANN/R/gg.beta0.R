gg.beta0 <-
  function(bb,sdata,Xp,Eyil,Ewil,Eui,bl.Li,bl.Ri){
    N<-nrow(sdata)
    L<-nrow(bl.Li)
    r.mat<-function(x) matrix(x,ncol=N,nrow=L,byrow=TRUE)
    c.mat<-function(x) matrix(x,ncol=N,nrow=L)
    exb<-exp(Xp%*%bb)
    numer<-apply(Eyil+Ewil,1,sum)
    denom<-apply(r.mat((1-sdata$d3)*exb)*bl.Ri+r.mat(sdata$d3*exb*Eui)*bl.Li,1,sum)
    denom[denom==0]=0.01
    gg<-numer/denom
    return(gg)
  }
loglik1 <-
  function(x0,sdata,Xp,Zp,bl.Li,bl.Ri){
    M<-ncol(Zp)
    P<-ncol(Xp)
    e0<-x0[1:M]
    #print(e0)
    b0<-x0[(M+1):(M+P)]
    #print(b0)
    g0<-x0[-c(1:(M+P))]
    pzi<-exp(Zp%*%e0)/(1+exp(Zp%*%e0))
    exb<-exp(Xp%*%b0)
    #print(g0)
    Lamd.Li<-t(bl.Li)%*%matrix(g0,ncol=1)
    Lamd.Ri<-t(bl.Ri)%*%matrix(g0,ncol=1)
    pc0<-(1-sdata$d3)*log(pzi)

    pc1<-sdata$d1*(1-exp(-Lamd.Ri*exb))
    pc2<-sdata$d2*(exp(-Lamd.Li*exb)-exp(-Lamd.Ri*exb))
    pc3<-sdata$d3*(1-pzi+pzi*exp(-Lamd.Li*exb))

    ll<-sum(pc0+log(pc1+pc2+pc3))
    return(-ll)
  }
