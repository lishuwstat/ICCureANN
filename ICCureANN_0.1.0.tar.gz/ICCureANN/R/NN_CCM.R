#' The main function to fit a neural-network mixture cure model with interval-censored data
#'
#' The mixture cure model is fitted for interval-censored survival data.
#' The cure (incidence) part is modeled using an artificial neural network,
#' while the latency part for uncured subjects follows a proportional hazards model.
#' An EM algorithm with a multiple-imputation strategy and monotone I-splines
#' is used for estimation.
#' @usage NN_CCM(survfun = formula(data), curefun = formula(data), data = parent.frame(),
#'        t.seq, beta.ini = NULL, gamma.ini = NULL,
#'        n.int = 5, order = 3, max.iter = 1000, cov.rate = 0.001,
#'        hidden_layers)

#' @param survfun A formula for the latency (PH) component, specified via \code{Surv(left,right)}.
#' @param curefun A one-sided formula (e.g., \code{~ z1 + z2 + ...}) for the cure/incidence component.
#' @param data A data frame that contains the interval endpoints and covariates.
#' @param t.seq A numeric vector of time points where the baseline cumulative hazard is evaluated (used for prediction and spline evaluation).
#' @param beta.ini Initial values for regression coefficients in the latency model. If \code{NULL}, a zero vector is used.
#' @param gamma.ini Initial values for the I-spline coefficients of the baseline cumulative hazard. If \code{NULL}, a small positive vector is used.
#' @param n.int Number of interior knots used for I-splines. Default is 5.
#' @param order Order of the spline basis functions. Default is 3 (cubic).
#' @param max.iter Maximum number of EM iterations. Default is 1000.
#' @param cov.rate Convergence tolerance. The algorithm stops when the parameter change criterion is below this value. Default is 0.001.
#' @param hidden_layers Integer vector specifying the hidden-layer structure passed to \code{neuralnet::neuralnet()} (e.g., \code{c(4,12)}).
#' @details
#' The interval-censored response should be specified using \code{Surv(L, R)}.
#' For left-censored observations, set \code{L = 0} and \code{R} equal to the inspection time.
#' For right-censored observations, set \code{R = NA}.

#' The baseline cumulative hazard is approximated by monotone I-splines with \code{n.int + order} basis functions.
#' The cure probability is estimated via a neural network with a multiple-imputation strategy:
#' at each EM iteration, multiple binary cure labels are imputed from the current posterior uncured probabilities,
#' multiple neural networks are trained, and predictions are averaged.
#' @return
#' A fitted \code{NN_CCM} object, a list containing:
#' \itemize{
#'   \item \code{latencyfit}: Estimated regression coefficients for the latency component.
#'   \item \code{ispline_gamma}: Estimated I-spline coefficients for the baseline cumulative hazard.
#'   \item \code{Uncureprob}: Estimated uncured probabilities for the training data.
#'   \item \code{Loglikelihood}: Observed-data log-likelihood at convergence.
#'   \item \code{loops}: Number of EM iterations.
#'   \item \code{order}, \code{knots}: I-spline specification.
#'   \item \code{mdata}: Processed data used internally.
#'   \item \code{mod1}--\code{mod5}: Neural network models trained in the last EM iteration (for prediction).
#' }
#' @references
#' Ren, J., Zhao, S., Deng, D. and Li, S. (2026).
#' Mixture cure rate model with artificial neural network for interval-censored data.
#' @note
#' The fitted neural networks (\code{mod1}--\code{mod5}) are stored for prediction.
#' If your dataset is large, storing these models may increase object size.
#' Consider setting a smaller network or saving only the final averaged predictions if memory is an issue.
#' @examples
#' \donttest{
#' data(sim_example)
#'
#' t.seq <- seq(
#'   0,
#'   max(c(sim_example$left, sim_example$right), na.rm = TRUE),
#'   length.out = 30
#' )
#' n.int=5
#' order=3
#'  beta.ini<-as.matrix(rep(0,2))
#'  gamma.ini<-as.matrix(rep(0.1,n.int+order))
#' fit <- NN_CCM(
#'   survfun = survival::Surv(left, right) ~ x1 + x2,
#'   curefun = ~ z1 + z2,
#'   data = sim_example,
#'   beta.ini=beta.ini,
#'   gamma.ini=gamma.ini,
#'   t.seq = t.seq,
#'   n.int = 5,
#'   order = 3,
#'   max.iter = 3000,
#'   cov.rate = 0.001,
#'   hidden_layers = c(4, 12)
#' )
#'
#' pzi_hat <- predict_NN(fit, sim_example)
#' head(pzi_hat)
#' }
#' @importFrom stats model.extract formula as.formula quantile nlm
#' @return A list with fitted parameters and NN models.
#' @export
NN_CCM <-
  function(survfun=formula(data),curefun=formula(data),data=parent.frame(),t.seq,
           beta.ini=NULL,gamma.ini=NULL,n.int=5,order=3,max.iter=1000,
           cov.rate=.001,hidden_layers){
    sdata <- data
    call <- match.call()
    mf <- match.call(expand.dots = FALSE)
    temp <- c("", "formula", "data", "na.action")
    mf <- mf[match(temp, names(mf), nomatch = 0)]
    mf[[1]] <- as.name("model.frame")
    avars <- all.vars(survfun)
    survfun1 <- as.formula(
      paste("survival::Surv(", avars[1], ",", avars[2], ",type='interval2')~",
            paste(avars[-c(1,2)], collapse="+"), sep="")
    )

    temp.x <- stats::terms(survfun1, data = sdata)
    temp.z <- stats::terms(curefun, data = sdata)
    mf$formula<-temp.x
    mf <- eval(mf, envir=parent.frame())
    Y <- model.extract(mf, "response")
    attr(temp.x, "intercept") <- 0
    attr(temp.z, "intercept") <- 0

    Xp <- stats::model.matrix(temp.x, sdata)
    colnames(Xp) <- paste0("x", 1:ncol(Xp))

    Zp <- stats::model.matrix(temp.z, sdata)
    colnames(Zp) <- paste0("z", 1:ncol(Zp))
    Zp <- data.frame(Zp)
    sdata$d1<-as.numeric(Y[,3]==2)
    sdata$d2<-as.numeric(Y[,3]==3)
    sdata$d3<-as.numeric(Y[,3]==0)
    sdata$Li<-Y[,1]
    sdata$Li[sdata$d1==1]<-0
    sdata$Ri<-Y[,2]
    sdata$Ri[sdata$d1==1]<-Y[sdata$d1==1,1]
    sdata$Ri[sdata$d3==1]<-NA

    # Estimates
    P<-ncol(Xp)
    M<-ncol(Zp)
    L<-n.int+order
    N<-nrow(sdata)
    threshold=0.1
    r.mat<-function(x) matrix(x,ncol=N,nrow=L,byrow=TRUE)
    c.mat<-function(x) matrix(x,ncol=N,nrow=L)
    if (is.null(beta.ini))  beta.ini  <- as.matrix(rep(0,P))
    if (is.null(gamma.ini)) gamma.ini <- as.matrix(rep(1,L))
    b0<-beta.ini
    g0<-gamma.ini

    ti <- unique(c(sdata$Li[sdata$d1 == 0], sdata$Ri[sdata$d3 == 0]))
    ti.max <- max(ti) + 1e-05
    ti.min <- min(ti) - 1e-05
    #knots <- seq(ti.min, ti.max, length.out = (n.int + 2))
    knots <-quantile(ti,seq(0,1,length.out = (n.int + 2)))
    #print(knots)
    bl.Li<-bl.Ri<-matrix(0,nrow=L,ncol=N)

    bt <- ICsurv::Ispline(t.seq,order=order,knots=knots)
    bl.Li[,sdata$d1==0]<-ICsurv::Ispline(sdata$Li[sdata$d1==0],order=order,knots=knots)
    bl.Ri[,sdata$d3==0]<-ICsurv::Ispline(sdata$Ri[sdata$d3==0],order=order,knots=knots)

    dif<-numeric()
    est.par<-matrix(ncol=P+L,nrow=max.iter)
    Eui<-last_pzi<-1-sdata$d3
    #Eui<-last_pzi<-ifelse(sdata$d3==1,0.5,1)

    ll<-numeric()
    dd<-1
    ii<-0
    while(dd>cov.rate & ii<max.iter){

      ii<-ii+1
      NN_train=NN_Cure(Eui,Zp,N,hidden_layers,threshold)
      pzi<-NN_train$uncureprob
      exb<-exp(Xp%*%b0)
      Lamd.Li<-t(bl.Li)%*%matrix(g0,ncol=1)
      Lamd.Ri<-t(bl.Ri)%*%matrix(g0,ncol=1)

      lambdai<-exb*(sdata$d1*Lamd.Ri+sdata$d2*Lamd.Li)
      omegai<-exb*(sdata$d2*(Lamd.Ri-Lamd.Li)+sdata$d3*Lamd.Li)
      lambdail<-c.mat(g0)*(r.mat(sdata$d1*exb)*bl.Ri+r.mat(sdata$d2*exb)*bl.Li)
      omegail<-c.mat(g0)*(r.mat(sdata$d2*exb)*(bl.Ri-bl.Li)+r.mat(sdata$d3*exb)*bl.Li)

      ci<-1-exp(-sdata$d1*lambdai)
      di<-1-exp(-sdata$d2*omegai)

      Eyil<-r.mat(sdata$d1/(sdata$d1*ci+1-sdata$d1))*lambdail
      Ewil<-r.mat(sdata$d2/(sdata$d2*di+1-sdata$d2))*omegail
      Eyi<-apply(Eyil,2,sum)
      Ewi<-apply(Ewil,2,sum)

      Eui<-1-sdata$d3+sdata$d3*pzi*exp(-Lamd.Li*exb)/(1-pzi+pzi*exp(-Lamd.Li*exb))

      # M-step

      fit2<-nlm(bb.gamma0,p=b0,sdata=sdata,Xp=Xp,Eyil=Eyil,Ewil=Ewil,Eui=Eui,bl.Li=bl.Li,bl.Ri=bl.Ri)

      if(!is.character(pzi) & !is.character(fit2)){
        print(ii)
        b0<-fit2$estimate
        g0<-gg.beta0(bb=b0,sdata=sdata,Xp=Xp,Eyil=Eyil,Ewil=Ewil,Eui=Eui,bl.Li=bl.Li,bl.Ri=bl.Ri)
        est.par[ii,]<-c(b0,g0)
        print(c(b0,g0))
        ll<-c(ll,loglik2(x0=est.par[ii,],pzi,L,sdata=sdata,Xp=Xp,Zp=Zp,bl.Li=bl.Li,bl.Ri=bl.Ri))
      }
      if(ii>2) dd<-sum(c(mean(pzi)-mean(last_pzi),b0-est.par[ii-1,1:P],g0-est.par[ii-1,-c(1:P)])^2)
      last_pzi=pzi
      print(round(c(b0,dd),3))
    }
    # After convergence
    loglik <- ll[ii]
    S_0 <- t(bt)%*%matrix(g0,ncol=1)
    betaX <- exp(Xp%*%b0)
    NN.em <- list(latencyfit=b0,ispline_gamma=g0,Uncureprob=pzi,Loglikelihood=loglik,tau=dd,
                  mdata=sdata,loops=ii,order=order,knots=knots,mod1=NN_train$mod1,mod2=NN_train$mod2,
                  mod3=NN_train$mod3,mod4=NN_train$mod4,mod5=NN_train$mod5,d3=sdata$d3,
                  Lamd.Li=Lamd.Li,exb=exb,knots=knots,Eui=Eui,S0=S_0,betaX=betaX,Z_cols=colnames(Zp))
    class(NN.em) <- "NN_CCM"
    return(NN.em)
  }


