#' @docType package
#' @name ICCureANN-package
#' @aliases ICCureANN
#'
#' @title Fit mixture cure rate model with artificial neural network for interval-censored data
#'
#' @description
#' Neural-network-based mixture cure model is a flexible framework for analyzing
#' interval-censored survival data, which allows a fraction of subjects to be cured.
#' The cure probability is modeled using an artificial neural network, while the
#' latent event time distribution for uncured individuals follows a proportional
#' hazards model. When the survival data are interval censored, this package provides
#' an efficient EM algorithm with monotone splines and a multiple imputation strategy
#' for model estimation.
#' @details
#' The main function is NN_CCM, which produces the parameter estimates for the
#' mixture cure model. The function predict_NN can be used to obtain the estimated
#' uncured probabilities for individuals with specified covariates.
#' @author
#' Junyao Ren, Shishun Zhao, Dianliang Deng, Shuwei Li \cr
#' Maintainer: Shuwei Li \email{seslishuw@gzhu.edu.cn}
#' @references
#' Ren, J., Zhao, S., Deng, D. and Li, S. (2026).
#' Mixture cure rate model with artificial neural network for interval-censored data.

#' @keywords package
"_PACKAGE"
