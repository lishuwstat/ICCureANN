#' @docType package
#' @name ICCureANN-package
#' @aliases ICCureANN-package
#'
#' @title Fit mixture cure rate model with ANN to interval-censored data
#'
#' @description
#' A flexible mixture cure rate model is proposed for analyzing interval-censored  data that   allow a fraction of subjects to be cured. In this model,  the cure probability is modeled with an  ANN  and the
#' the latent event time distribution related to uncured individuals follows a  PH  model.
#' The baseline cumulative hazard function is approximated with monotone splines.
#' This package provides an EM algorithm with a multiple imputation strategy.
#' @details
#' The main function is ICCureANN, which produces the parameter estimates for the
#' mixture cure model. The function predict_NN is used to estimate the
#' uncured probabilities for individuals with prespecified covariates.
#' @author
#' Junyao Ren, Shishun Zhao, Dianliang Deng, Shuwei Li \cr
#' Maintainer: Shuwei Li \email{seslishuw@gzhu.edu.cn}
#' @references
#' Ren, J., Zhao, S., Deng, D. and Li, S. (2026).
#' Mixture cure rate model with artificial neural network for interval-censored data.

#' @keywords package
"_PACKAGE"
