#' Predict uncured probabilities from a fitted cure model
#'
#' Based on the fitted  \code{\link{ICCureANN}} model, uncured probabilities are calculated for new individuals
#' with prespecified covariate values.
#'
#' @param object A object from the function \code{\link{ICCureANN}}.
#' @param tdata A data.frame containing cure-related covariates.
#'
#' @return A numeric vector of predicted uncured probabilities.
#'
#'
#' @export
predict_NN <-function(object,tdata){
  zcols <- object$Z_cols
  F=nrow(tdata)
  ## 2. 构造 new.z（保持列顺序一致）
  new.z <- as.data.frame(tdata[, zcols, drop = FALSE])

  pzi1 <- as.vector(neuralnet::compute(object$mod1,new.z)$net.result)
  pzi2 <- as.vector(neuralnet::compute(object$mod2,new.z)$net.result)
  pzi3 <- as.vector(neuralnet::compute(object$mod3,new.z)$net.result)
  pzi4 <- as.vector(neuralnet::compute(object$mod4,new.z)$net.result)
  pzi5 <- as.vector(neuralnet::compute(object$mod5,new.z)$net.result)
  pzi=c(1,1)
  for (z in 1:F){pzi[z] <- (pzi1[z] + pzi2[z] + pzi3[z] + pzi4[z] + pzi5[z]) / 5}
  return(pzi)
}
