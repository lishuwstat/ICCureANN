
NN_Cure=function(Eui,inputdata,N,best_hidden_layers,threshold){
  ###################################### NN step#####################################
  multipleuncureprob=matrix(1:5*N, nrow=N,ncol=5)  #形成矩阵
  for (j in 1:N){multipleuncureprob[j,] <- stats::rbinom(5,size = 1,prob=Eui[j])}  #对矩阵赋值 model the response as binary

  uncureprob1 <- uncureprob2 <- uncureprob3 <- uncureprob4 <- uncureprob5 <-  c(1 ,1)

  uncureprob1=as.factor(multipleuncureprob[,1])
  uncureprob2=as.factor(multipleuncureprob[,2])
  uncureprob3=as.factor(multipleuncureprob[,3])
  uncureprob4=as.factor(multipleuncureprob[,4])
  uncureprob5=as.factor(multipleuncureprob[,5])

  update_cureb <- c(1,1)
  ##################################    NN  ####    5 ——multiple imputation-based technique #############################
  dataa1=data.frame(uncureprob1,inputdata)
  k <- ncol(inputdata)
  z_names <- paste0("z", 1:k)
  z_terms <- paste(z_names, collapse = " + ")
  fml1b <- stats::as.formula(paste0("(uncureprob1 == 1) ~ ", z_terms))
  # #####################NN 1
  # 定义神经网络结构并训练模型
  mod1 <- neuralnet::neuralnet(
    fml1b,
    data = dataa1,
    hidden = best_hidden_layers, # 设置隐藏层神经元数量
    threshold = threshold,
    linear.output = FALSE,
    act.fct = 'logistic'
  )
  update_cureb1=as.vector(neuralnet::compute(mod1,inputdata)$net.result)

  ############NN 2
  dataa2=data.frame(uncureprob2,inputdata)
  fml2b <- stats::as.formula(paste0("(uncureprob2 == 1) ~ ", z_terms))
  mod2 <- neuralnet::neuralnet(
    fml2b,
    data = dataa2,
    hidden = best_hidden_layers,
    threshold = threshold,
    linear.output = FALSE,
    act.fct = 'logistic'
  )
  update_cureb2=as.vector(neuralnet::compute(mod2,inputdata)$net.result)

  ############NN 3
  dataa3=data.frame(uncureprob3,inputdata)
  fml3b <- stats::as.formula(paste0("(uncureprob3 == 1) ~ ", z_terms))
  mod3 <- neuralnet::neuralnet(
    fml3b,
    data = dataa3,
    hidden = best_hidden_layers,
    threshold = threshold,
    linear.output = FALSE,
    act.fct = 'logistic'
  )
  update_cureb3=as.vector(neuralnet::compute(mod3,inputdata)$net.result)

  ############NN 4
  dataa4=data.frame(uncureprob4,inputdata)
  fml4b <- stats::as.formula(paste0("(uncureprob4 == 1) ~ ", z_terms))
  mod4 <- neuralnet::neuralnet(
    fml4b,
    data = dataa4,
    hidden = best_hidden_layers,
    threshold = threshold,
    linear.output = FALSE,
    act.fct = 'logistic'
  )
  update_cureb4=as.vector(neuralnet::compute(mod4,inputdata)$net.result)

  ############NN 5
  dataa5=data.frame(uncureprob5,inputdata)
  fml5b <- stats::as.formula(paste0("(uncureprob5 == 1) ~ ", z_terms))
  mod5 <- neuralnet::neuralnet(
    fml5b,
    data = dataa5,
    hidden = best_hidden_layers,
    threshold = threshold,
    linear.output = FALSE,
    act.fct = 'logistic'
  )
  update_cureb5=as.vector(neuralnet::compute(mod5,inputdata)$net.result)



  #multi-imputation
  for (z in 1:N){update_cureb[z] <- (update_cureb1[z] + update_cureb2[z] + update_cureb3[z] +
                                       update_cureb4[z] + update_cureb5[z]) / 5}

  return(list(uncureprob=update_cureb,mod1=mod1,mod2=mod2,mod3=mod3,mod4=mod4,mod5=mod5))
}

