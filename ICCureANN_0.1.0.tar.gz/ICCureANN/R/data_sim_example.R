#' Simulated interval-censored data under a mixture cure model
#'
#'This interval-censored data set is generated from a mixture cure model.
#'The data are used to illustrate the usage of \code{ICCureANN} and related
#'prediction function.
#'
#' \strong{Data generating mechanism:}
#' \enumerate{
#' \item \emph{True uncure status indicator.}
#'   For subject \eqn{i}, the uncured indicator \eqn{U_i} is generated
#'   from a logistic model
#'   \deqn{
#'     \Pr(U_i = 1 \mid Z_i)
#'     = \frac{\exp(\eta_0 + \eta_1 Z_{i1} + \eta_2 Z_{i2})}
#'            {1 + \exp(\eta_0 + \eta_1 Z_{i1} + \eta_2 Z_{i2})},
#'   }
#'   where \eqn{Z_{i1}, Z_{i2} \sim N(0,1)} independently and
#'   \eqn{\eta = (1.5, -5, -3)^\top}.
#'
#'   \item \emph{Failure time model.}
#'   Given \eqn{U_i = 1}, the failure time \eqn{T_i} follows
#'   a PH model with the conditional cumulative hazard function
#'    \deqn{
#'    \Lambda(t \mid  X_i)=\Lambda_0(t)  \exp(\beta_1X_{i1} +  \beta_2X_{i2}),
#'    }
#'   where \eqn{\Lambda_0(t) = \log(1+t) + t^{3/2}},
#'   \eqn{X_i  = (X_{i1}, X_{i2})^\top = (Z_{i1}, Z_{i2})^\top} and
#'   \eqn{\beta = (\beta_1, \beta_2)^{\top} = (0.5, -0.5)^\top}.
#'
#'   \item \emph{Interval-censored data (left/right  endpoints).}
#'   For each subject, the number of examinations are first generated
#'   from a Poisson distribution. Then gaps between consecutive examinations
#'   are generated from an exponential distribution. The left and right endpoints
#'   are obtained by contrasting the failure time with the generated examination times.
#' }
#'
#' @format A data.frame with columns:
#' \describe{
#'   \item{left}{Left endpoint of the interval-censored data}
#'   \item{right}{Right endpoint of the interval-censored data (\code{NA} indicates right censoring).}
#'   \item{x1, x2}{Covariates used in the PH model.}
#'   \item{z1, z2}{Covariates used in the ANN.}
#' }
#'
#' @source Simulated data generated for illustrating the ANN-based
#' mixture cure model.
"sim_example"
