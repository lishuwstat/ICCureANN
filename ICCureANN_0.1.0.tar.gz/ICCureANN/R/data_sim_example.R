#' Simulated interval-censored data under a mixture cure model
#'
#' This dataset is generated from a mixture cure model with
#' interval-censored event times. The data are used to illustrate
#' the usage of \code{NN_CCM} and related prediction functions.
#'
#' \strong{Data generating mechanism:}
#' \enumerate{
#'   \item \emph{Cure status.}
#'   For subject \eqn{i}, the uncured indicator \eqn{U_i} is generated
#'   from a logistic model
#'   \deqn{
#'     \Pr(U_i = 1 \mid Z_i)
#'     = \frac{\exp(\eta_0 + \eta_1 Z_{i1} + \eta_2 Z_{i2})}
#'            {1 + \exp(\eta_0 + \eta_1 Z_{i1} + \eta_2 Z_{i2})},
#'   }
#'   where \eqn{Z_{i1}, Z_{i2} \sim N(0,1)} independently and
#'   \eqn{\eta = (1.5, -5, -3)^\top}.
#'
#'   \item \emph{Latency time.}
#'   Given \eqn{U_i = 1}, the latent event time \eqn{T_i} follows
#'   a proportional hazards model with baseline cumulative hazard
#'   \deqn{
#'     \Lambda_0(t) = \log(1+t) + t^{3/2},
#'   }
#'   and covariates \eqn{X_i = (Z_{i1}, Z_{i2})^\top} with
#'   regression coefficients \eqn{\beta = (0.5, -0.5)^\top}.
#'
#'   \item \emph{Interval censoring.}
#'   Observation times are generated through a Poisson process,
#'   leading to left-, interval-, and right-censored observations.
#' }
#'
#' @format A data.frame with columns:
#' \describe{
#'   \item{left}{Left endpoint of the censoring interval}
#'   \item{right}{Right endpoint of the censoring interval}
#'   \item{x1, x2}{Latency covariates}
#'   \item{z1, z2}{Cure covariates}
#' }
#'
#' @source Simulated data generated for illustrating the NN-based
#' mixture cure model.
"sim_example"
