
loglik2 <-
  function(x0,pzi,L,sdata,Xp,Zp,bl.Li,bl.Ri){
    P<-ncol(Xp)
    b0<-x0[1:P]
    g0<-x0[(P+1):(L+P)]
    exb<-exp(Xp%*%b0)
    Lamd.Li<-t(bl.Li)%*%matrix(g0,ncol=1)
    Lamd.Ri<-t(bl.Ri)%*%matrix(g0,ncol=1)
    pc0<-(1-sdata$d3)*log(pzi)

    pc1<-sdata$d1*(1-exp(-Lamd.Ri*exb))
    pc2<-sdata$d2*(exp(-Lamd.Li*exb)-exp(-Lamd.Ri*exb))
    pc3<-sdata$d3*(1-pzi+pzi*exp(-Lamd.Li*exb))

    ll<-sum(pc0+log(pc1+pc2+pc3))
    return(-ll)
  }
